package com.lightbend.akka.sample;

import com.google.inject.Guice;
import com.google.inject.Injector;


public class TwitterApiServiceMain {
	
	public static void main(String [] args) {
		
		Injector guice = Guice.createInjector(new TwitterApiGuiceModel());
		TwitterApiService twitserv = guice.getInstance(TwitterApiService.class);

		
		if (twitserv.ImplementorClassInfo.contains("TwitterApiLiveImpl")) {
			System.out.println("This is connected to Live");
			System.out.println(twitserv.twitterInstance.getClass());
		}
		else if (twitserv.ImplementorClassInfo.contains("TwitterApiMockImpl")){
			System.out.println("This is connected to Mock Class");
			System.out.println(twitserv.twitterInstance.getClass());
		}
	}

}
