package com.lightbend.akka.sample;


import javax.inject.Inject;

import twitter4j.Twitter;


public class TwitterApiService {

	 final public Twitter twitterInstance;
	 final public String ImplementorClassInfo;
	 @Inject
	 public TwitterApiService(TwitterApi twitterInstance) {
		 this.twitterInstance= twitterInstance.get_twitterInst();
		 this.ImplementorClassInfo=twitterInstance.getClass().getName();
	 }

	
	 	 
}
