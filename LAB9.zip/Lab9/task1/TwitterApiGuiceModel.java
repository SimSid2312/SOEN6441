package com.lightbend.akka.sample;

public class TwitterApiGuiceModel extends com.google.inject.AbstractModule{

	@Override
	protected void configure() {
		//bind(TwitterApi.class).to(TwitterApiMockImpl.class);
		
	}

}
